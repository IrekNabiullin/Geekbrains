package com.geekbrains.game;

public class Rules {
    public static final int CELL_SIZE = 80;
    public static final int CELL_HALF_SIZE = 40;
}
