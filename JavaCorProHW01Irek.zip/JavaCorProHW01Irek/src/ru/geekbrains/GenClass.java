package ru.geekbrains;

import java.io.Serializable;

public class GenClass<T extends Serializable> {//в дженериках нет слова implements
}
