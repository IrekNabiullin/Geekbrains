package ru.geekbrains;

public class Orange extends Fruits {
    private Float weight;
    Orange(){
        weight = 1.5f;
    }
    public Float getWeights() {
        return weight;
    }
}
