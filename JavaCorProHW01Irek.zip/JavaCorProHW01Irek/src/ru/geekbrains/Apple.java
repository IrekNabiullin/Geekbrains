package ru.geekbrains;

public class Apple extends Fruits {
    private Float weight;
    Apple(){
        weight = 1.0f;
    }
    public Float getWeights() {
        return weight;
    }
}
