package ru.geekbrains;

import java.util.ArrayList;

public class BoxOfFruit<T extends Fruits> {
    //для создания ArrayList c фруктами используем правильное обобщение
    //не забываем про метод add (добавить фрукт в коробку) - -яблоко положить к апельсинам нельзя {
    private ArrayList<Float> fruits;
    private T obj;
    private Float weight;

    public ArrayList<Float> getFruits() {
        return fruits;
    }

    public T getObj() {
        return obj;
    }

    public void setObj(T obj) {
        this.obj = obj;
    }


    // метод добавления фруктов в коробку
    public void addFruit(int quantity, Float weight) {
        for (int i = 0; i < quantity; i++) {
            fruits.add(weight); // в этой строке выдает NullPointerException, не успел разобраться почему.
        }
    }

    // метод удаления фруктов из коробки
    public void removeFruit(int quantity) {
        for (int i = 1; i < quantity; i++) {
            fruits.remove(weight);
        }
    }

    // метод определения веса коробки
    public Float getWeight() {
        Float weightOfBox = 0.0f;
        for (int i = 1; i < fruits.size(); i++) {
            weightOfBox += weight;
        }
        System.out.println("Weight of " + this + " box = " + weightOfBox);
        return weightOfBox;
    }

    // метод сравннеия веса коробки с другой коробкой того же вида
    public boolean compare(BoxOfFruit<?> anotherBox) {
        return Math.abs(this.getWeight() - anotherBox.getWeight()) < 0.0001f;


    }
}
