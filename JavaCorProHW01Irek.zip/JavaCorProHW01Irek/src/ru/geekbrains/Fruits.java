package ru.geekbrains;

public class Fruits {
    private Float weight;
    public Float getWeights() {
        return weight;
    }
}
