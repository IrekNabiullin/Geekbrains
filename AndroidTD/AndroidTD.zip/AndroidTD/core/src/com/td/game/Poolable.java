package com.td.game;

/**
 * Created by FlameXander on 23.09.2017.
 */

public interface Poolable {
    boolean isActive();
}
